from Firma import Firma


class DuzaFirma(Firma):
    def __init__(self, nazwa: str, KRS: str):
        super().__init__(nazwa, KRS)

